package com.jass.market;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JassMarketApplicationTests {

	@Test
	void contextLoads() {
	}

}
